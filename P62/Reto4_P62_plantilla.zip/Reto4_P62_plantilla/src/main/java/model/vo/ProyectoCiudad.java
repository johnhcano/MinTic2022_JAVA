package model.vo;

public class ProyectoCiudad {

    
}
