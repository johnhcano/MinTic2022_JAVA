package model.vo;

public class LiderCiudad {

    

}
